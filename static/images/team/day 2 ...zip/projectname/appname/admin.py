from django.contrib import admin

# Register your models here.


from appname.models import Student
admin.site.register(Student)